﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SyntonicStudios.SSWebsite.WebUI;

namespace SyntonicStudios.SSWebsite.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
