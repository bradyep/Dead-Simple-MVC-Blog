﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SyntonicStudios.SSWebsite.WebUI.Controllers
{
    public class GameController : Controller
    {
        //
        // GET: /Game/

        /*
        // This method may list out all my games in the future.
        public ActionResult Index()
        {
            return View();
        }
        */

        public ActionResult Sleepwalker()
        {
            return View();
        }

        public ActionResult Jacks2000()
        {
            return View();
        }

    }
}
