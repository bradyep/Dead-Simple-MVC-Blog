﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SyntonicStudios.SSWebsite.WebUI.Controllers
{
    public class ProjectController : Controller
    {
        //
        // GET: /Project/

        /*
        // This Controller should eventually list out all projects
        public ActionResult Index()
        {
            return View();
        }
        */

        public ActionResult StockExplorer()
        {
            return View();
        }

    }
}
